<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Like extends Model
{
    
    protected $fillable = ['user', 'comment_id', 'post_id'];
    

}
