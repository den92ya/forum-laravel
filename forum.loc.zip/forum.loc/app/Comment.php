<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Comment extends Model {

    protected $fillable = ['user', 'thread', 'text'];

    public function getCreatedAtAttribute($date) {
        return Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('H:i:s / d.m.Y');
    }

    public function post() {
        return $this->belongsTo(Post::class);
    }

    public function creator() {
        return $this->belongsTo(User::class, 'user');
    }

}
