<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Post extends Model
{
    protected $table = 'thread';
    protected $fillable=['user', 'topic', 'text'];
    
    public function getCreatedAtAttribute($date)
    {
        return Carbon::createFromFormat('Y-m-d H:i:s', $date)->format('H:i:s / d.m.Y');
    }
    
    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
}
