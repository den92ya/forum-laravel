<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use App\Post;
use App\Like;
use App\Comment;
use DB;

class ReplyController extends Controller {

    public function index(Post $id) {
        $data = [
            'mythreads' => DB::table('likes')->where('comment_id', 1)->count(),
        ];

        return view('reply', compact('id'), $data);
    }

    /*
      public function index($id)
      {
      $id = Thread::find($id);
      return view('reply', compact('id'));
      }
     */

    public function ncomment(Request $request) {
        /* массив кастамезированных выводов об ошибоках */
        $comments = [
            'size' => 'The :attribute must be exactly :size.',
        ];
        /* правила валидации для входных данных */
        $rules = [
            'comm' => 'required|string',
        ];

        /* запускае валидатор */
        $v = Validator::make($request->all(), $rules, $comments);


        if ($v->fails()) { //проверка на ошибки
            return redirect()->back()->withErrors($v->errors());
        } else {


            $input = $request->all();
            $comment = new Comment;

            function test_input($data) {  // чистим входные данные от не нужных символов, и
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            /* магический метод добавления данных в БД */
            $comment->user = auth()->user()->id;
            $comment->post_id = $request->id;
            $comment->text = test_input($input['comm']);
            // $message->tmb = $filename;
            //dd($message);


            /* Сохраняем данные в БД */
            $comment->save();
            // sleep(5);
            return redirect()->back();
            //return $input;
        }
    }

    public function like(Request $request, Comment $id) {

        $input = $request->all();
        $like = new Like;
        $like->user = auth()->user()->id;
        $like->comment_id = $id->id;

        $idlike = DB::table('likes')->where(['user' => auth()->user()->id, 'comment_id' => $id->id])->get();
        if ($idlike == '[]' || $idlike[0]->user != auth()->user()->id) {
            $like->save();
        }

        return redirect()->back();
    }

}
