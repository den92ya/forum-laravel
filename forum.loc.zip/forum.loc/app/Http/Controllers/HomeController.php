<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use Illuminate\Support\Facades\Validator;
use App\User;
use DB;

class HomeController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void

      public function __construct()
      {
      $this->middleware('auth');
      }

      /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function home() {
        $data = [
            'mythreads' => DB::table('thread')->where('user', auth()->user()->id)->latest()->paginate(),
        ];




        return view('home', $data);
    }

    public function data() {
        return view('home.data');
    }

    public function editdate(Request $request) {
        //dd(request()->all());
        /* массив кастамезированных выводов об ошибоках */
        $comments = [
            'size' => 'The :attribute must be exactly :size.',
        ];
        /* правила валидации для входных данных */
        $rules = [
            'name' => 'required|string',
            'email' => 'required|string',
        ];

        /* запускае валидатор */
        $v = Validator::make($request->all(), $rules, $comments);


        if ($v->fails()) { //проверка на ошибки
            return redirect()->back()->withErrors($v->errors());
        } else {


            $item = User::findOrFail(auth()->user()->id)->update($request->all()); // Вернет true или false

            return redirect()->back();
        }
    }

    public function avatar() {
        return view('home.avatar');
    }

    public function editavatar(Request $request) {
        //dd(request()->all());
        /* массив кастамезированных выводов об ошибоках */
        $avatars = [
            'image' => 'Wrong extension of :attribute. Have to be jpeg,jpg,gig,png.',
        ];
        /* правила валидации для входных данных */
        $rules = [
            'img' => 'image|max:10000|mimes:jpeg,jpg,gig,png',
        ];

        /* запускае валидатор */
        $v = Validator::make($request->all(), $rules, $avatars);


        if ($v->fails()) { //проверка на ошибки
            return redirect()->back()->withErrors($v->errors());
        } else {

//$request->avatar = 1;
            $input = $request->all();

            if (isset($input['img'])) { // проверяем на существование ключа img (картинка)
                //dd(request()->all());
                $picture = $input['img'];


                $file_name = auth()->user()->id . '.' . $picture->getClientOriginalExtension();

                $size = $picture->getSize();   // размер изобрадения
                $extention = $picture->getClientOriginalExtension(); // расширение изобоажения


                /* проверка изображения на размеры и расшерение */
                if (preg_match('/[.](JPG)|(jpg)|(jpeg)|(JPEG)|(gif)|(GIF)|(png)|(PNG)$/', $extention)) {//проверка формата исходного изображения
                    if ($size < 2000000) {
                        $picture->move(public_path('avatar'), $file_name);

                        $item = User::findOrFail(auth()->user()->id)->update(['avatar' => $file_name]); // Вернет true или false
                    }
                }
            }



            return redirect()->back();
        }
    }

//    public function password() {
//        return view('home.password');
//    }

    public function password() {
        $data = [
            'password' => auth()->user()->password,
            'password2' => password_verify('123456yhn', auth()->user()->password),
        ];




        return view('home.password', $data);
    }

    public function editpassword(Request $request) {
        //dd(request()->all());
        /* массив кастамезированных выводов об ошибоках */
        $password = [
            'size' => 'The :attribute must be exactly :size.',
        ];
        /* правила валидации для входных данных */
        $rules = [
            'password1' => 'required|min:6|string',
            'password2' => 'required|min:6|string',
            'password3' => 'required|min:6|string',
        ];

        /* запускае валидатор */
        $v = Validator::make($request->all(), $rules, $password);


        if ($v->fails()) { //проверка на ошибки
            return redirect()->back()->withErrors($v->errors());
        } else {
            $input = $request->all();

            $hash = password_verify($input['password1'], auth()->user()->password);


            if (!empty($hash)) {
                if ($input['password2'] == $input['password3']) {

                    $hash = password_hash($input['password2'], PASSWORD_BCRYPT, array('cost' => 10));
                    $item = User::findOrFail(auth()->user()->id)->update(['password' => $hash]);
                }
            }
            return redirect()->back();
        }
    }

}
