<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Post;
use Illuminate\Support\Facades\Validator;

class IndexController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void

      public function __construct()
      {
      $this->middleware('auth');
      }

      /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     
    public function home() {
        return view('home');
    }
*/
    public function index() {
        $data = [
            'threads' => Post::latest()->paginate(),
        ];
        return view('thread', $data);
    }

    public function nthread(Request $request) {
        /* массив кастамезированных выводов об ошибоках */
        $messages = [
            'required' => 'The :attribute field is required.',
            'size' => 'The :attribute must be exactly :size.',
        ];
        /* правила валидации для входных данных */
        $rules = [
            'topic' => 'required|string|max:50',
            'text' => 'required|string',
        ];

        /* запускае валидатор */
        $v = Validator::make($request->all(), $rules, $messages);


        if ($v->fails()) { //проверка на ошибки
            return redirect()->back()->withErrors($v->errors());
        } else {


            $input = $request->all();
            $message = new Post;

            function test_input($data) {  // чистим входные данные от не нужных символов, и
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }

            /* магический метод добавления данных в БД */
            $message->user = auth()->user()->id;
            $message->topic = test_input($input['topic']);
            $message->text = test_input($input['text']);
            // $message->tmb = $filename;
            // dd($input);


            /* Сохраняем данные в БД */
            $message->save();
            // sleep(5);
            return redirect()->back();
            //return $input;
        }
    }

}
