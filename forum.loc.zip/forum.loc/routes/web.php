<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/




Route::get('/', ['uses' => 'IndexController@index', 'as' => 'welcome']);

Auth::routes();
Route::get('/home', ['uses' => 'HomeController@home', 'as' => 'home']);
Route::get('/home/data', ['uses' => 'HomeController@data', 'as' => 'data']);
Route::get('/home/avatar', ['uses' => 'HomeController@avatar', 'as' => 'avatar']);
Route::get('/home/password', ['uses' => 'HomeController@password', 'as' => 'password']);
//Route::get('/home', 'HomeController@index')->name('home');
Route::post('/', 'IndexController@nthread');
//Route::post('/{page}', 'HomeController@nthread');

Route::get('reply/{id}/', ['uses' => 'ReplyController@index', 'as' => 'reply'])->where(['id' => '[0-9]+']);

Route::get('reply/{id}/like', ['uses' => 'ReplyController@like', 'as' => 'like'])->where(['id' => '[0-9]+']);

Route::post('/reply/{id}/', 'ReplyController@ncomment');
//Route::post('/home/data/', 'HomeController@dataedit');
Route::patch('/home/data/', 'HomeController@editdate');
Route::patch('/home/avatar/', 'HomeController@editavatar');
Route::patch('/home/password/', 'HomeController@editpassword');