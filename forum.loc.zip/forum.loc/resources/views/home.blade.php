@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Личный кабинет</div>

                <div class="panel-body">
                    @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                    @endif



                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/data">
                                    Личные данные
                                </a> 
                            </span>
                        </h3>
                    </div>

                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/avatar">
                                    Изменить аватар
                                </a> 
                            </span>
                        </h3>
                    </div>

                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/password">
                                    Изменить пароль
                                </a> 
                            </span>
                        </h3>
                    </div>

                </div>
            </div>

            @if ( ! $mythreads->isEmpty() )


            <div class="panel panel-default">
                <div class="panel-heading">Мои записи</div>


                @foreach ($mythreads as $mythread)
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                            <a href="/reply/{{ $mythread->id }}">
                                {{ $mythread->topic }}
                            </a> 
                        </span>
                        <span class="pull-right label label-info">
                            {{-- 17:15:00 / 03.07.20016 --}}
                            {{ $mythread->created_at }}
                        </span>
                    </h3>
                </div>

                @endforeach

            </div>

            @endif

        </div>
    </div>
</div>
@endsection
