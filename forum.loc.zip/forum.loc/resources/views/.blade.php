@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Форумы</div>

                @if ( ! $threads->isEmpty() )
                @foreach ($threads as $thread)
                
                
                

                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                       <a href="/reply/{{ $thread->id }}">
                 {{ $thread->topic }}
                 </a> (0)
                        </span>
                        <span class="pull-right label label-info">
                            {{-- 17:15:00 / 03.07.20016 --}}
                            {{ $thread->created_at }}
                        </span>
                    </h3>
                </div>
                
            
                
                @endforeach
                @else
                <div class="text-center">
        Темы не созданы
    </div> 
                @endif
            </div>
            
            <div class="text-center">
        {!! $threads->render() !!}
    </div> 
            
        
@if ( ! Auth::guest())  
@include('thread.form')        
@endif       
        
        
        </div>
    </div>
</div>
@endsection