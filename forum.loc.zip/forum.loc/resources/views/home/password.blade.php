@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Изменить пароль</div>

                <div class="panel-body">
                    

                    
                    
                    <form action="" class="form-horizontal" enctype="multipart/form-data" method="post"  id="feedback_form" onsubmit="return validate_feedback()">
                       {!! method_field('patch') !!}
                        <input name="_token" type="hidden" value="{!! csrf_token() !!}" />
                        
                        <div class="form-group{{ $errors->has('password1') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Старый пароль</label>

                            <div class="col-md-6">
                                <input id="password1" type="text" class="form-control" name="password1" value="{{ auth()->user()->password1 }}">

                                @if ($errors->has('password1'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password1') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('password2') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Новый пароль</label>

                            <div class="col-md-6">
                                <input id="password2" type="text" class="form-control" name="password2" value="{{ auth()->user()->password2 }}">

                                @if ($errors->has('password2'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password2') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                        <div class="form-group{{ $errors->has('password3') ? ' has-error' : '' }}">
                            <label for="name" class="col-md-4 control-label">Повторите пароль</label>

                            <div class="col-md-6">
                                <input id="password3" type="text" class="form-control" name="password3" value="{{ auth()->user()->password3 }}">

                                @if ($errors->has('password3'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password3') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        
                     

                       

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Сохранить
                                </button>
                            </div>
                        </div>
                    </form>
               
                    
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
