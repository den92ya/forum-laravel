@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    {{ $id->topic }}
                </div>
                <div class="panel-body">

                    {{ $id->text }}
                </div>
            </div>

            @if ( ! $id->comments->isEmpty() )
            @foreach ($id->comments as $comment)
            <div class="panel panel-default">

                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                        <img style="border-radius: 50%; " height="20" width="20" src="../avatar/{{ $comment->creator->avatar }}"> 
                        </span>
                        <span>
                            {{ $comment->creator->name }}
                        </span>
                        <span class="pull-right label label-info">
                            {{ $comment->created_at }}
                        </span>
                    </h3>
                </div>
                <div class="panel-body">
                    {{ $comment->text }}

                    
                    <div class="text-right">
                        <a href="/reply/{{ $comment->id }}/like/">
                    Нравиться {{  DB::table('likes')->where(['comment_id' => $comment->id])->count() }} 
                    </a>
            </div>
                    
                </div>
                
            </div>






            @endforeach
            @else
            <div class="text-center">
                Комментариев нет.
            </div> <br>
            @endif

            @if ( ! Auth::guest())  
            <div class="panel panel-default">
                <div class="panel-heading">Написать комментарий</div>

                <div class="panel-body">

                    <form action="" class="form-horizontal" enctype="multipart/form-data" method="post"  id="feedback_form" onsubmit="return validate_feedback()">
                        <input name="_token" type="hidden" value="{!! csrf_token() !!}" />



                        <div class="form-group{{ $errors->has('comm') ? ' has-error' : '' }}">


                            <div style="padding: 0px 10px 0px 10px">


                                <textarea value="{{ old('comm') }}" class="form-control" type="comm" rows="3" placeholder="Текст сообщения" name="comm" cols="50" id="comm"></textarea>


                                @if ($errors->has('comm'))
                                <span class="help-block">
                                    <strong>{{ $errors->first('comm') }}</strong>
                                </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Написать
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            @endif   

        </div>
    </div>
</div>
@endsection