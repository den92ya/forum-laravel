<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <?php echo e($id->topic); ?>

                </div>
                <div class="panel-body">

                    <?php echo e($id->text); ?>

                </div>
            </div>

            <?php if( ! $id->comments->isEmpty() ): ?>
            <?php $__currentLoopData = $id->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="panel panel-default">

                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                        <img style="border-radius: 50%; " height="20" width="20" src="../avatar/<?php echo e($comment->creator->avatar); ?>"> 
                        </span>
                        <span>
                            <?php echo e($comment->creator->name); ?>

                        </span>
                        <span class="pull-right label label-info">
                            <?php echo e($comment->created_at); ?>

                        </span>
                    </h3>
                </div>
                <div class="panel-body">
                    <?php echo e($comment->text); ?>


                    
                    <div class="text-right">
                        <a href="/reply/<?php echo e($comment->id); ?>/like/">
                    Нравиться <?php echo e(DB::table('likes')->where(['comment_id' => $comment->id])->count()); ?> 
                    </a>
            </div>
                    
                </div>
                
            </div>






            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <div class="text-center">
                Комментариев нет.
            </div> <br>
            <?php endif; ?>

            <?php if( ! Auth::guest()): ?>  
            <div class="panel panel-default">
                <div class="panel-heading">Написать комментарий</div>

                <div class="panel-body">

                    <form action="" class="form-horizontal" enctype="multipart/form-data" method="post"  id="feedback_form" onsubmit="return validate_feedback()">
                        <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />



                        <div class="form-group<?php echo e($errors->has('comm') ? ' has-error' : ''); ?>">


                            <div style="padding: 0px 10px 0px 10px">


                                <textarea value="<?php echo e(old('comm')); ?>" class="form-control" type="comm" rows="3" placeholder="Текст сообщения" name="comm" cols="50" id="comm"></textarea>


                                <?php if($errors->has('comm')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('comm')); ?></strong>
                                </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Написать
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <?php endif; ?>   

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>