<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Изменить пароль</div>

                <div class="panel-body">
                    

                    
                    
                    <form action="" class="form-horizontal" enctype="multipart/form-data" method="post"  id="feedback_form" onsubmit="return validate_feedback()">
                       <?php echo method_field('patch'); ?>

                        <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                        
                        <div class="form-group<?php echo e($errors->has('password1') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Старый пароль</label>

                            <div class="col-md-6">
                                <input id="password1" type="text" class="form-control" name="password1" value="<?php echo e(auth()->user()->password1); ?>">

                                <?php if($errors->has('password1')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password1')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('password2') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Новый пароль</label>

                            <div class="col-md-6">
                                <input id="password2" type="text" class="form-control" name="password2" value="<?php echo e(auth()->user()->password2); ?>">

                                <?php if($errors->has('password2')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password2')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('password3') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-md-4 control-label">Повторите пароль</label>

                            <div class="col-md-6">
                                <input id="password3" type="text" class="form-control" name="password3" value="<?php echo e(auth()->user()->password3); ?>">

                                <?php if($errors->has('password3')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password3')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                     

                       

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Сохранить
                                </button>
                            </div>
                        </div>
                    </form>
               
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>