<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Личный кабинет</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>



                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/data">
                                    Личные данные
                                </a> 
                            </span>
                        </h3>
                    </div>

                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/avatar">
                                    Изменить аватар
                                </a> 
                            </span>
                        </h3>
                    </div>

                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <span>
                                <a href="/home/password">
                                    Изменить пароль
                                </a> 
                            </span>
                        </h3>
                    </div>

                </div>
            </div>

            <?php if( ! $mythreads->isEmpty() ): ?>


            <div class="panel panel-default">
                <div class="panel-heading">Мои записи</div>


                <?php $__currentLoopData = $mythreads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mythread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                            <a href="/reply/<?php echo e($mythread->id); ?>">
                                <?php echo e($mythread->topic); ?>

                            </a> 
                        </span>
                        <span class="pull-right label label-info">
                            
                            <?php echo e($mythread->created_at); ?>

                        </span>
                    </h3>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <?php endif; ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>