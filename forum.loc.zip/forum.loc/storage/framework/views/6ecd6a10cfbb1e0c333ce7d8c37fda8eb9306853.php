<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Форумы</div>

                <?php if( ! $threads->isEmpty() ): ?>
                <?php $__currentLoopData = $threads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thread): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




                <div class="panel-heading">
                    <h3 class="panel-title">
                        <span>
                            <a href="/reply/<?php echo e($thread->id); ?>">
                                <?php echo e($thread->topic); ?>

                            </a> 
                        </span>
                        <span class="pull-right label label-info">
                            
                            <?php echo e($thread->created_at); ?>

                        </span>
                    </h3>
                </div>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="text-center">
                    Темы не созданы
                </div> 
                <?php endif; ?>
            </div>

            <div class="text-center">
                <?php echo $threads->render(); ?>

            </div> 


            <?php if( ! Auth::guest()): ?>  
            <?php echo $__env->make('thread.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>        
            <?php endif; ?>       


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>