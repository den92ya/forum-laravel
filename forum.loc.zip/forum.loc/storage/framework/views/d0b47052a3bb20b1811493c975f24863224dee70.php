<div class="panel panel-default">
                <div class="panel-heading">Создать тему</div>

                <div class="panel-body">
                    
                      <form action="" class="form-horizontal" enctype="multipart/form-data" method="post"  id="feedback_form" onsubmit="return validate_feedback()">
                        <input name="_token" type="hidden" value="<?php echo csrf_token(); ?>" />
                        
                        <div class="form-group<?php echo e($errors->has('topic') ? ' has-error' : ''); ?>">
                            <label for="topic" class="col-md-4 control-label">Название темы</label>

                            <div class="col-md-6">
                                <input id="topic" type="topic" class="form-control" name="topic" value="<?php echo e(old('topic')); ?>">

                                <?php if($errors->has('topic')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('topic')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('text') ? ' has-error' : ''); ?>">
                            <label for="text" class="col-md-4 control-label">Текст</label>

                            <div class="col-md-6">
                                
                                
                                <textarea value="<?php echo e(old('text')); ?>" class="form-control" type="text" rows="3" placeholder="Текст сообщения" name="text" cols="50" id="text"></textarea>
                                

                                <?php if($errors->has('text')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('text')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Создать
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>